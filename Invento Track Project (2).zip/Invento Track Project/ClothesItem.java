public class ClothesItem extends ProductItem {

    public ClothesItem(int codeNumber, String productName, double productPrice, int quantityStock, int minimumStock) {
        super(codeNumber, productName, productPrice, quantityStock, minimumStock, "Clothing");
    }
}
