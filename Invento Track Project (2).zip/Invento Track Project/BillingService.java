import java.util.ArrayList;
import java.util.List;

public class BillingService {

    private final StockService stockService;
    private final List<ProductItem> cartItems;

    public BillingService(StockService stockService) {
        this.stockService = stockService;
        cartItems = new ArrayList<>();
    }

    public void addToCart(int code, int qty) {
        ProductItem p = stockService.findByCode(code);
        if (p == null) {
            throw new RuntimeException("Product does not exist!");
        }
        if (p.getQuantityStock() < qty) {
            throw new RuntimeException("Insufficient stock!");
        }
        p.setQuantityStock(p.getQuantityStock() - qty);
        stockService.updateProduct(p);

        for (int i = 0; i < qty; i++) {
            cartItems.add(p);
        }

        System.out.println("Added to cart: " + qty + " " + p.getProductName());
    }

    public void removeFromCart(int code) {
        ProductItem toRemove = null;
        for (ProductItem p : cartItems) {
            if (p.getCodeNumber() == code) {
                toRemove = p;
                break;
            }
        }
        if (toRemove != null) {
            cartItems.remove(toRemove);

            ProductItem stockItem = stockService.findByCode(code);
            if (stockItem != null) {
                stockItem.setQuantityStock(stockItem.getQuantityStock() + 1);
                stockService.updateProduct(stockItem);
            }

            System.out.println("Removed from cart: " + toRemove.getProductName());
        } else {
            System.out.println("Item not in cart!");
        }
    }

    public String invoiceSummary() {
        double total = 0;
        String text = "\n--- INVOICE ---\n";

        for (ProductItem p : cartItems) {
            text += p.getProductName() + " : " + String.format("%.2f", p.getProductPrice()) + "\n";
            total += p.getProductPrice();
        }

        text += "TOTAL : " + String.format("%.2f", total) + "\n";

        return text;
    }

    public void clearCart() {
        cartItems.clear();
        System.out.println("Cart cleared!");
    }
}

