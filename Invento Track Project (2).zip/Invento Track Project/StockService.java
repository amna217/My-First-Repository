import java.util.ArrayList;
import java.util.List;

public class StockService {

    private final List<ProductItem> allProducts;

    public StockService() {
        allProducts = new ArrayList<>();
    }

    public void addProduct(ProductItem p) {
        allProducts.add(p);
        System.out.println("Added Product: " + p.getProductName());
    }

    public void updateProduct(ProductItem p) {
        for (int i = 0; i < allProducts.size(); i++) {
            if (allProducts.get(i).getCodeNumber() == p.getCodeNumber()) {
                allProducts.set(i, p);
                System.out.println("Updated Product: " + p.getProductName());
                return;
            }
        }
        System.out.println("Product not found to update!");
    }

    public void removeProduct(int code) {
        ProductItem target = null;
        for (ProductItem p : allProducts) {
            if (p.getCodeNumber() == code) {
                target = p;
                break;
            }
        }
        if (target != null) {
            allProducts.remove(target);
            System.out.println("Removed Product: " + target.getProductName());
        } else {
            System.out.println("Product not found to remove!");
        }
    }

    public ProductItem findByCode(int code) {
        for (ProductItem p : allProducts) {
            if (p.getCodeNumber() == code) return p;
        }
        return null;
    }

    public List<ProductItem> findByCategory(String category) {
        List<ProductItem> result = new ArrayList<>();
        for (ProductItem p : allProducts) {
            if (p.getProductCategory().equalsIgnoreCase(category)) {
                result.add(p);
            }
        }
        return result;
    }

    public List<ProductItem> searchByName(String keyword) {
        List<ProductItem> result = new ArrayList<>();
        for (ProductItem p : allProducts) {
            if (p.getProductName().toLowerCase().contains(keyword.toLowerCase())) {
                result.add(p);
            }
        }
        return result;
    }

    public List<String> lowStockAlerts() {
        List<String> alerts = new ArrayList<>();
        for (ProductItem p : allProducts) {
            if (p.getQuantityStock() < p.getMinimumStock()) {
                alerts.add("!!! Low Stock: " + p.getProductName() + " Qty: " + p.getQuantityStock());
            }
        }
        return alerts;
    }

    public List<ProductItem> getAllProducts() {
        return allProducts;
    }
}

