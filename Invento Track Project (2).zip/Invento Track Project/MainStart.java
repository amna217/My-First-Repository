import java.util.Scanner;

public class MainStart {

    private static final StockService stock = new StockService();
    private static final BillingService billing = new BillingService(stock);
    private static final ReportsService report = new ReportsService();

    public static void main(String[] args) {
        report.connectStock(stock);
        fillSampleData();

        try (Scanner sc = new Scanner(System.in)) {
            boolean running = true;

            while (running) {
                showMainMenu();
                String choice = sc.nextLine();

                switch (choice) {
                    case "1": stockMenu(sc); break;
                    case "2": billingMenu(sc); break;
                    case "3": reportMenu(sc); break;
                    case "0": running = false; break;
                    default: System.out.println("Invalid choice!"); break;
                }
            }
        }

        System.out.println("Exiting System. Bye!");
    }

    private static void fillSampleData() {
        stock.addProduct(new ElectronicsItem(1,"Smartphone",1000,10,2));
        stock.addProduct(new GroceryItem(2,"Basmati Rice",50,100,10));
        stock.addProduct(new ClothesItem(3,"Cotton T-Shirt",200,20,5));
    }

    private static void showMainMenu() {
        System.out.println("\n--- Invento Track--- ");
        System.out.println("1. Stock Menu");
        System.out.println("2. Billing Menu");
        System.out.println("3. Reports Menu");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void stockMenu(Scanner sc) {
        System.out.println("\n--- Stock Menue ---");
        System.out.println("1. Add Product");
        System.out.println("2. Update Product Qty");
        System.out.println("3. Delete Product");
        System.out.println("4. Check Stock Level");
        System.out.println("5. List By Category");
        System.out.println("6. Search By Name");
        System.out.println("7. Low Stock Alerts");
        System.out.println("8. Show All Products");

        String choice = sc.nextLine();

        switch(choice) {
            case "1": addProductPrompt(sc); break;
            case "2": updateProductPrompt(sc); break;
            case "3": removeProductPrompt(sc); break;
            case "4": checkStockPrompt(sc); break;
            case "5": listCategoryPrompt(sc); break;
            case "6": searchNamePrompt(sc); break;
            case "7": showLowStock(); break;
            case "8": showAllProducts(); break;
            default: System.out.println("Invalid Choice"); break;
        }
    }

    private static void addProductPrompt(Scanner sc) {
        System.out.print("Type 1=Electronics,2=Grocery,3=Clothes : ");
        int type = Integer.parseInt(sc.nextLine());
        System.out.print("Code Number: "); int code = Integer.parseInt(sc.nextLine());
        System.out.print("Name: "); String name = sc.nextLine();
        System.out.print("Price: "); double price = Double.parseDouble(sc.nextLine());
        System.out.print("Quantity: "); int qty = Integer.parseInt(sc.nextLine());
        System.out.print("Min Stock: "); int min = Integer.parseInt(sc.nextLine());

        ProductItem p;
        if(type == 1) p = new ElectronicsItem(code,name,price,qty,min);
        else if(type==2) p = new GroceryItem(code,name,price,qty,min);
        else p = new ClothesItem(code,name,price,qty,min);

        stock.addProduct(p);
    }

    private static void updateProductPrompt(Scanner sc) {
        System.out.print("Code Number: "); int code = Integer.parseInt(sc.nextLine());
        ProductItem p = stock.findByCode(code);
        if(p==null){ System.out.println("Not Found"); return;}
        System.out.print("New Qty: "); int q = Integer.parseInt(sc.nextLine());
        p.setQuantityStock(q);
        stock.updateProduct(p);
    }

    private static void removeProductPrompt(Scanner sc) {
        System.out.print("Code Number: "); int code = Integer.parseInt(sc.nextLine());
        stock.removeProduct(code);
    }

    private static void checkStockPrompt(Scanner sc) {
        System.out.print("Code Number: "); int code = Integer.parseInt(sc.nextLine());
        ProductItem p = stock.findByCode(code);
        if(p!=null) System.out.println("Stock: "+p.getQuantityStock());
        else System.out.println("Not Found");
    }

    private static void listCategoryPrompt(Scanner sc) {
        System.out.print("Category: "); String cat = sc.nextLine();
        for(ProductItem p: stock.findByCategory(cat)){
            System.out.println(p.getCodeNumber()+" "+p.getProductName()+" Qty:"+p.getQuantityStock());
        }
    }

    private static void searchNamePrompt(Scanner sc) {
        System.out.print("Name  "); String key = sc.nextLine();
        for(ProductItem p: stock.searchByName(key)){
            System.out.println(p.getCodeNumber()+" "+p.getProductName());
        }
    }

    private static void showLowStock() {
        for(String s: stock.lowStockAlerts()) System.out.println(s);
    }

    private static void showAllProducts() {
        for(ProductItem p: stock.getAllProducts()){
            System.out.println(p.getCodeNumber()+" "+p.getProductName()+" "+p.getProductCategory()+" Qty:"+p.getQuantityStock());
        }
    }

    private static void billingMenu(Scanner sc) {
        System.out.println("\n--- Billing Menue ---");
        System.out.println("1. Add to Cart");
        System.out.println("2. Remove from Cart");
        System.out.println("3. Show Invoice");
        System.out.println("4. Clear Cart");

        String choice = sc.nextLine();

        switch(choice){
            case "1": addToCartPrompt(sc); break;
            case "2": removeFromCartPrompt(sc); break;
            case "3": System.out.println(billing.invoiceSummary()); break;
            case "4": billing.clearCart(); break;
            default: System.out.println("Invalid Choice"); break;
        }
    }

    private static void addToCartPrompt(Scanner sc){
        System.out.print("Code Number: "); int code = Integer.parseInt(sc.nextLine());
        System.out.print("Qty: "); int qty = Integer.parseInt(sc.nextLine());
        try{ billing.addToCart(code, qty);}
        catch(RuntimeException e){ System.out.println(e.getMessage());}
    }

    private static void removeFromCartPrompt(Scanner sc){
        System.out.print("Code Number: "); int code = Integer.parseInt(sc.nextLine());
        billing.removeFromCart(code);
    }

    private static void reportMenu(Scanner sc){
        System.out.println("\n--- REPORTS MENU ---");
        System.out.println("1. Daily Sales Report");
        System.out.println("2. Stock Report");

        String choice = sc.nextLine();
        if(choice.equals("1")) report.dailySalesReport();
        else if(choice.equals("2")) report.stockReport();
        else System.out.println("Invalid Choice");
    }
}

