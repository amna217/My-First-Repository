import java.util.List;
import java.time.LocalDate;

public class ReportsService {

    private StockService stock;

    public void connectStock(StockService s) {
        stock = s;
    }

    public void dailySalesReport() {
        System.out.println("\n--- DAILY SALES REPORT ---");
        System.out.println("Date: " + LocalDate.now());
        System.out.println("No actual sales yet (simulation).");
        System.out.println("----------------------------");
    }

    public void stockReport() {
        System.out.println("\n--- STOCK REPORT ---");
        List<ProductItem> products = stock.getAllProducts();
        for (ProductItem p : products) {
            System.out.println(p.getProductName() + " : " + p.getQuantityStock());
        }
        
    }
}

