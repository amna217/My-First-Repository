public class ElectronicsItem  extends ProductItem {

    public ElectronicsItem(int codeNumber, String productName, double productPrice, int quantityStock, int minimumStock) {
        super(codeNumber, productName, productPrice, quantityStock, minimumStock, "Electronics");
    }
}
    

