public abstract class ProductItem {

    private final int codeNumber;
    private final String productName;
    private final double productPrice;
    private  int quantityStock;
    private final int minimumStock;
    private final String productCategory;

    public ProductItem(int codeNumber, String productName, double productPrice, int quantityStock, int minimumStock, String productCategory) {
        this.codeNumber = codeNumber;
        this.productName = productName;
        this.productPrice = productPrice;
        this.quantityStock = quantityStock;
        this.minimumStock = minimumStock;
        this.productCategory = productCategory;
    }

    public int getCodeNumber() {
        return codeNumber;
    }

    public String getProductName() {
        return productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public int getQuantityStock() {
        return quantityStock;
    }

    public void setQuantityStock(int qty) {
        this.quantityStock = qty;
    }

    public int getMinimumStock() {
        return minimumStock;
    }

    public String getProductCategory() {
        return productCategory;
    }
}
