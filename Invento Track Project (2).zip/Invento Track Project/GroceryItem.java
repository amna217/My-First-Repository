public class GroceryItem extends ProductItem {

    public GroceryItem(int codeNumber, String productName, double productPrice, int quantityStock, int minimumStock) {
        super(codeNumber, productName, productPrice, quantityStock, minimumStock, "Grocery");
    }
}
